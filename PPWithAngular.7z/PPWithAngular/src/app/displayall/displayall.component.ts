import { Component, OnInit } from '@angular/core';
import { MyServiceService, Employee } from '../my-service.service';

@Component({
  selector: 'app-displayall',
  templateUrl: './displayall.component.html',
  styleUrls: ['./displayall.component.css']
})
export class DisplayallComponent implements OnInit {

  service:MyServiceService;
  employees:Employee[]=[];
  
  constructor(service:MyServiceService) { 
    this.service=service;
  }

  ngOnInit() {

    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
    console.log(this.employees);

  }

}
