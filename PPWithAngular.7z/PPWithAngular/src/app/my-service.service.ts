import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  isLogin:boolean=true;
  employees:Employee[]=[];
  transactions:Transactions[]=[];
  tempTransaction:Transactions[]=[];
  //loginCheckAcc:number;

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchEmployees();
    this.fetchTransactions();
  }

  fetched:boolean=false;
  fetchedT:boolean=false;

  fetchEmployees()
  {
    this.http.get('./assets/Employee.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  fetchTransactions()
  {
    this.http.get('./assets/Transactions.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetchedT)
        {
          this.convertTransaction(data);
          this.fetchedT=true;
        }
      }
    );
  }

  getEmployees():Employee[]
  {
    return this.employees;
  }

  getTransactions():Transactions[]
  {
    return this.transactions;
  }

  convert(dataE:any)
  {
    for(let o of dataE)
    {
      let e=new Employee(o.caccount,o.cname,o.cphone,o.cpassword,o.ccity,o.cbalance);
      this.employees.push(e);
    }
  }

  convertTransaction(dataT:any)
  {
    for(let o of dataT)
    {
      let e=new Transactions(o.tid,o.taccount_sender,o.taccount_reciver,o.tamount);
      this.transactions.push(e);
      console.log(this.transactions)
    }
  }

  miniStatement(caccount:number):Transactions[]{
    this.tempTransaction=[];
    for(let i=0;i<this.transactions.length;i++)
    {
      let e=this.transactions[i];
      if(caccount==e.taccount_sender)
      {
        this.tempTransaction.push(e);
      }
    }
    return this.tempTransaction;
  }
  
  
  delete(caccount:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.employees.length;i++)
    {
      let e=this.employees[i];
      if(caccount==e.caccount)
      {
        foundIndex=i;
        break;
      }
    }
    this.employees.splice(foundIndex,1);
  }

  add(e:Employee){
    this.employees.push(e);
    var myJSON = JSON.stringify(this.employees);
    console.log(myJSON);
  }

  addTransaction(e:Transactions){
    this.transactions.push(e);
  }

  showBalance(data:Employee):number{
    let caccount = data.caccount; 
    for(let i=0;i<this.employees.length;i++)
      {
        if(caccount == this.employees[i].caccount)
        {
          //alert(this.employees[i].cbalance)
          let cbalance=this.employees[i].cbalance;
          return cbalance;
        }else{
          alert("Account No does not matched!")
        }
      }
  }

  depositeBalance(caccount_first:number,cbalance:number){
      console.log(caccount_first,cbalance)

      for(let i=0;i<this.employees.length;i++)
      {
        if(caccount_first == this.employees[i].caccount)
        {
          let depositeB:number=this.employees[i].cbalance;
          this.employees[i].cbalance=depositeB + cbalance;
          alert(10 + 30)
          // alert(this.employees[i].cbalance);
          alert("Amount Deposited from "+caccount_first+" Updated Balance : "+this.employees[i].cbalance);
          break;
        }
      }
  }
  
  withdrawBalance(caccount_first:number,cbalance:number){
    console.log(caccount_first,cbalance)

    for(let i=0;i<this.employees.length;i++)
    {
      if(caccount_first == this.employees[i].caccount)
      {
        let depositeB:number=this.employees[i].cbalance;
        this.employees[i].cbalance=depositeB - cbalance;
        alert(10 + 30)
        // alert(this.employees[i].cbalance);
        alert("Amount Withdrawn from "+caccount_first+" Updated Balance : "+this.employees[i].cbalance);
        break;
      }
    }
  }

  update(data:Employee)
  {
    let caccount=data.caccount;
    for(let i=0;i<this.employees.length;i++)
    {
      if(caccount === this.employees[i].caccount)
      {
        this.employees[i].cname=data.cname;
        this.employees[i].cbalance=data.cbalance;
        break;
      }
    }
  }

  login(data:Employee):boolean
  {
    let caccount=data.caccount;
    let cpassword=data.cpassword;
    //this.loginCheckAcc=data.caccount;
    //alert(this.loginCheckAcc);
    for(let i=0;i<this.employees.length;i++)
    {
      if(caccount == this.employees[i].caccount && cpassword == this.employees[i].cpassword)
      {
        alert("Value Matched!")
        this.isLogin=!this.isLogin;
        // this.employees[i].cname=data.cname;
        // this.employees[i].cbalance=data.cbalance;
        return true;
        break;
      }else {
        return false;
      }

    }
  }

  search(caccount:number):Employee[]
  {
    let resultEmp:Employee[]=[];
    let o:Employee;
    var flag = 0;
    for(let i=0;i<this.employees.length;i++)
    {
      if(caccount==o.caccount)
      {
        resultEmp.push(o);
        alert("ID : "+o.caccount+"Name :"+o.cname);
        flag=1;
        break;
      }
    }
    if(flag==0){
      alert("No data Exist!");
    }
    return resultEmp;
  }
}

export class Employee{
  caccount:number;
  cname:string;
  cphone:number;
  cpassword:string;
  ccity:string;
  cbalance:number;

    constructor(caccount:number,cname:string,cphone:number,cpassword:string,ccity:string,cbalance:number)
    {
      this.cbalance=cbalance;
      this.caccount=caccount;
      this.cname=cname;
      this.cphone=cphone;
      this.cpassword=cpassword;
      this.ccity=ccity;
    }
}

export class Transactions{
  tid:number;
  taccount_sender:number;
  taccount_reciver:number;
  tamount:number;


    constructor(tid:number,taccount_sender:number,taccount_reciver:number,tamount:number)
    {
      this.tid=tid;
      this.taccount_sender=taccount_sender;
      this.taccount_reciver=taccount_reciver;
      this.tamount=tamount;
    }
}