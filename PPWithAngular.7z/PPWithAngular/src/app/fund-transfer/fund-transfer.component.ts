import { Component, OnInit } from '@angular/core';
import { MyServiceService, Transactions } from '../my-service.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  isLogin:boolean=true;
  createdTransaction:Transactions;
  
 
  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  fundTransfer(data:any){
    let caccount_first=data.caccount;
    let caccount_second=data.caccount_second;
    let cbalance=data.cbalance;

    this.service.depositeBalance(caccount_first,cbalance);
    this.service.withdrawBalance(caccount_second,cbalance)
    
    this.createdTransaction=new Transactions(cbalance*4,caccount_first,caccount_second,data.cbalance);
    this.service.addTransaction(this.createdTransaction)
  }

  ngOnInit() {
  }

}
