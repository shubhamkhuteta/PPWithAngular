import { Component, OnInit } from '@angular/core';
import { MyServiceService, Employee } from '../my-service.service';
import { ShowBalanceComponent } from '../show-balance/show-balance.component';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})

export class EmployeeListComponent implements OnInit {

  service:MyServiceService;
  router:Router;

  constructor(service:MyServiceService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  employees:Employee[]=[];
  

  delete(caccount:number)
  {
    this.service.delete(caccount);
    this.employees=this.service.getEmployees();
  }

  isDeposite:boolean=true;
  isWithdraw:boolean=true;
  isTransfer:boolean=true;
  isLogin:boolean=true;
  
  depositeAmount()
  {
    this.isDeposite=!this.isDeposite;
    this.isWithdraw=this.isWithdraw;
  }

  withdrawAmount()
  {
    this.isWithdraw=!this.isWithdraw;
    this.isDeposite=this.isDeposite;
  }

  fundTransfer(){
    this.isTransfer=!this.isTransfer;
  }

  login(data:any){
    if(this.service.login(data)){
      this.isLogin=this.service.isLogin;
      this.router.navigate(['app-homepage']);
    }else{
      alert("Values does not matched!")
    }
    
    //this.employees=this.service.getEmployees();
  }
  update(data:any)
  {
    this.service.update(data);
    this.employees=this.service.getEmployees();
  }

  column:string="caccount"; 
  order:boolean=true;

  sort(column:string)
  {    
    if(this.column==column )
    {
      this.order=!this.order;
    }
    else
    {
      this.order=true;
      this.column=column;
    }
  }
  
  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }

  
}
